﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tecles : MonoBehaviour {

	// Use this for initialization
	private Animator animator;
	void Start () {
	animator = this.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update ()
	{

		var vertical = Input.GetAxis ("Vertical");
		var horizontal = Input.GetAxis ("Horizontal");

		if (vertical > 0) {
		
			animator.SetInteger ("Action", 2);
		} else if (vertical < 0) {

			animator.SetInteger ("Action", 3);
		} else if (horizontal > 0) {

			animator.SetInteger ("Action", 1);
		} else if (horizontal < 0) {

			animator.SetInteger ("Action", 0);
		}

		else if ((horizontal == 0) && (vertical == 0)) {

		animator.SetInteger ("Action", 0);
		}
	}
}
